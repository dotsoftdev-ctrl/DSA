# Website Creation Tracker

- [x] Create index.html (Home Page)
- [x] Create style.css (Styling)
- [x] Create script.js (Interactivity)
- [x] Create about.html (About Page)
- [x] Create courses.html (Courses Page)
- [x] Create contact.html (Contact Page)
